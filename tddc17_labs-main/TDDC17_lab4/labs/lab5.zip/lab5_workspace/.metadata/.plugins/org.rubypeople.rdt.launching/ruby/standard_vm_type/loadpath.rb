puts RUBY_VERSION
puts $LOAD_PATH - ['.']